const express = require('express');
const axios = require('axios');

const app = express();
app.use(express.json());

const DRONE_CONFIG_URL = ' https://script.google.com/macros/s/AKfycbzwclqJRodyVjzYyY-NTQDb9cWG6Hoc5vGAABVtr5-jPA_ET_2IasrAJK4aeo5XoONiaA/exec';
const DRONE_LOG_URL = 'https://app-tracking.pockethost.io/api/collections/drone_logs/records';

// GET /configs/:id
app.get("/configs/:id", async (req, res) => {
  const id = Number(req.params.id);

  try {
    const response = await axios.get(DRONE_CONFIG_URL);
    const data = response.data.data;

    const drone = data.find((d) => d.drone_id === id);

    if (!drone) {
      return res.status(404).send({ error: "drone_id not found" });
    }

    if (drone.max_speed == null) {
      drone.max_speed = 100;
    } else if (drone.max_speed > 110) {
      drone.max_speed = 110;
    }

    res.send({
      drone_id: drone.drone_id,
      drone_name: drone.drone_name,
      light: drone.light,
      country: drone.country,
      max_speed: drone.max_speed, 
      population:drone.population
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).send("Error fetching data");
  }
});

app.get('/', async (req, res) => {

  try {
    const response = await axios.get(DRONE_CONFIG_URL);
    let droneConfig = response.data;

    // Check max_speed constraints
    if (droneConfig.max_speed < 100) {
      droneConfig.max_speed = 100;
    } else if (droneConfig.max_speed > 110) {
      droneConfig.max_speed = 110;
    }

    res.json(droneConfig);
  } catch (error) {
    res.status(500).send('Error fetching drone config');
  }
});

// GET /status/:id
app.get("/status/:id", async (req, res) => {
  const id = Number(req.params.id);

  try {
    const response = await axios.get(DRONE_CONFIG_URL);
    const data = response.data.data;

    const drone = data.find((d) => d.drone_id === id);

    if (!drone) {
      return res.status(404).send({ error: "drone_id not found" });
    }

    res.send({
      condition : drone.condition
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).send("Error fetching data");
  }
});



// GET /logs
app.get("/logs", async (req, res) => {
  try {
    const response = await axios.get(DRONE_LOG_URL);
    let data = response.data.items;

    let logs = data.map((item) => ({
      drone_id: item.drone_id,
      drone_name: item.drone_name,
      created: item.created,
      country: item.country,
      celsius: item.celsius,
    }));

    res.send(logs);
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).send("Error fetching data");
  }
});


// POST /logs
app.post("/logs", async (req, res) => {
  const { celsius, drone_id, drone_name, country } = req.body;

  if (!celsius || !drone_id || !drone_name || !country) {
    return res
      .status(400)
      .send(
        "Missing required fields: celsius, drone_id, drone_name, or country"
      );
  }

  try {
    const { data } = await axios.post(
      { celsius, drone_id, drone_name, country },
      {
        celsius: celsius,
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    console.log("Insert complete");
    res.status(200).send("Insert complete");
  } catch (error) {
    console.error("Error: ", error.message);
    res.status(500).send("Error handling the data");
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
